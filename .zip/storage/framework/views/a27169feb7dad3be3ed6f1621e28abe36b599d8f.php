<?php $__env->startSection('title', $title.' / Новая'); ?>
<?php $__env->startSection('header'); ?>
    <a href="<?php echo e(route('categories.index', ['type' => $type])); ?>"><?php echo e($title); ?></a> / Новая
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route('categories.store', ['type' => $type])); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-9">
                <label for="name">Название категории</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="col-3">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-success col-12">Добавить</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>