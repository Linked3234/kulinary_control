<?php $__env->startSection('title', 'Товары / Новый'); ?>
<?php $__env->startSection('header'); ?>
    <a href="<?php echo e(route('goods.index')); ?>">Товары</a> / Новый
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route('goods.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-9">
                <label for="name">Название товара</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="col-3">
                <label for="measure">Единица измерения</label>
                <select name="measure" id="measure" class="form-control" required>
                    <option value="л.">Литры</option>
                    <option value="кг.">Килограммы</option>
                    <option value="шт.">Штуки</option>
                    <option value="м.">Метры</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label for="category_good">Категория (товарная)</label>
                <select name="category_good" id="category_good" class="form-control" required>
                    <?php $__currentLoopData = $categories_good; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="category_stock">Категория (складская)</label>
                <select name="category_stock" id="category_stock" class="form-control" required>
                    <?php $__currentLoopData = $categories_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="category_manufacturing">Категория (производственная)</label>
                <select name="category_manufacturing" id="category_manufacturing" class="form-control" required>
                    <?php $__currentLoopData = $categories_manufacturing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-success col-12">Добавить</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>