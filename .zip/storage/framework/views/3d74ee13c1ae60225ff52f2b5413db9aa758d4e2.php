<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('header'); ?>

    
    
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-3">

            
            <ul class="categories_list">
                <li <?php if($category_id == 'all'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('goods.list', ['category_id' => 'all'])); ?>">Все</a></li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li <?php if($value->id == $category_id): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('goods.list', ['category_id' => $value->id])); ?>"><?php echo e($value->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>
        <div class="col-6">
            <table class="table table-goods-order" border="0">
                
                
                    
                    
                    
                    
                
                
                <tbody>
                <?php $__currentLoopData = $goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td class="good_name" style="width: 80%;"><?php echo e($value->name); ?></td>
                        
                            
                        
                        <td style="width: 20%;">
                            <div class="create-order" style="width: 250px;">
                                <input type="hidden" name="good_id" value="<?php echo e($value->id); ?>">
                                <input type="hidden" name="category_id" value="<?php echo e($value->category_good()->id); ?>">
                                <input type="hidden" name="category_manufacturing" value="<?php echo e($value->category_manufacturing()->id); ?>">
                                <input type="hidden" name="category_stock" value="<?php echo e($value->category_stock()->id); ?>">
                                <button type="button" class="act-minus btn btn-primary" style="display: inline-block;">-</button>
                                <input type="number" name="count" min="0" max="100000" value="0" style="display: inline-block; width: 70px;" class="form-control">
                                <button type="button" class="act-plus btn btn-primary" style="display: inline-block;">+</button>
                                <button type="button" class="btn btn-primary basket_add"><i class="fas fa-shopping-basket"></i></button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-3">
            
            <div class="col-12">
                <button type="button" class="btn btn-default clear-basket">Очистить корзину</button>
            </div>
            <div id="basket_items" class="col-12">
                <?php echo $basket_list; ?>

            </div>
            <div class="col-12">
                <button type="button" class="btn btn-default create_order_btn" data-toggle="modal" data-target="#create_order">Отправить заказ</button>
            </div>
        </div>
    </div>

    
    
        
            
                
                    
                    
                        
                    
                
                
                    
                        
                            
                            
                        
                    
                
                
                    
                    
                    
                    
                    
                    
                
            
        
    


    
    <div class="modal fade" id="create_order" tabindex="-1" role="dialog" aria-labelledby="create_order" aria-hidden="true">
        <form method="POST" action="<?php echo e(route('order.create')); ?>">
            <?php echo csrf_field(); ?>
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="create_order_title">Оформление заказа</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-12">
                                    <label for="comment">Комментарий к заказу</label>
                                    <textarea name="comment" id="comment" placeholder="Необязательно" class="form-control"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
                            <button type="submit" class="btn btn-success">Оформить</button>
                        </div>
                    </div>
                </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>