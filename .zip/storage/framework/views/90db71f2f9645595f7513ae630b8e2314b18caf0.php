<?php $__env->startSection('title', 'Товары / Новый'); ?>
<?php $__env->startSection('header'); ?>
    <a href="<?php echo e(route('goods.index')); ?>">Товары</a> / Новый
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="POST" action="<?php echo e(route('goods.update', ['id' => $good->id])); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-9">
                <label for="name">Название товара</label>
                <input type="text" name="name" class="form-control" value="<?php echo e($good->name); ?>" required>
            </div>
            <div class="col-3">
                <label for="measure">Единица измерения</label>
                <select name="measure" id="measure" class="form-control" required>

                    <?php if($good->measure == 'л.'): ?>
                        <option value="л." selected>Литры</option>
                    <?php else: ?>
                        <option value="л.">Литры</option>
                    <?php endif; ?>
                    <?php if($good->measure == 'кг.'): ?>
                            <option value="кг." selected>Килограммы</option>
                    <?php else: ?>
                            <option value="кг.">Килограммы</option>
                    <?php endif; ?>
                    <?php if($good->measure == 'шт.'): ?>
                            <option value="шт." selected>Штуки</option>
                    <?php else: ?>
                            <option value="шт.">Штуки</option>
                    <?php endif; ?>
                    <?php if($good->measure == 'м.'): ?>
                            <option value="м." selected>Метры</option>
                    <?php else: ?>
                            <option value="м.">Метры</option>
                    <?php endif; ?>

                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <label for="category_good">Категория (товарная)</label>
                <select name="category_good" id="category_good" class="form-control" required>
                    <?php $__currentLoopData = $categories_good; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->id == $good->category_good): ?>
                            <option value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-4">
                <label for="category_stock">Категория (складская)</label>
                <select name="category_stock" id="category_stock" class="form-control" required>
                    <?php $__currentLoopData = $categories_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->id == $good->category_stock): ?>
                            <option value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-2">
                <label for="category_manufacturing">Категория (производственная)</label>
                <select name="category_manufacturing" id="category_manufacturing" class="form-control" required>
                    <?php $__currentLoopData = $categories_manufacturing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value->id == $good->category_manufacturing): ?>
                            <option value="<?php echo e($value->id); ?>" selected><?php echo e($value->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-2">
                <label for="hidden">Отображение</label>
                <select name="hidden" id="hidden" class="form-control" required>
                    <?php if($good->hidden == 'false'): ?>

                        <option value="0" selected>Показывать</option>
                        <option value="1">Скрыть</option>

                    <?php else: ?>

                        <option value="0">Показывать</option>
                        <option value="1" selected>Скрыть</option>

                    <?php endif; ?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-3">
                <label>&nbsp;</label>
                <button type="submit" class="btn btn-success col-12">Сохранить изменения</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>