<?php $__env->startSection('title'); ?>
    Заказ № <?php echo e($order->order_id); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>

    Заказ № <?php echo e($order->order_id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <p>Дата заказа: <?php echo e(date('d.m.Y H:i', $order->date)); ?></p>
    <p>Комментарий: <?php echo e($order->comment); ?></p>
    <?php echo $order->goods_mail; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>