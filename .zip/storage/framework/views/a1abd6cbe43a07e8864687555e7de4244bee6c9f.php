<?php $__env->startSection('title', 'Список заказов'); ?>
<?php $__env->startSection('header', 'Список заказов'); ?>

<?php $__env->startSection('content'); ?>

    <table class="table" border="0">
        <thead>
        <tr>
            <th>Пользователь</th>
            <th>№ заказа</th>
            <th>Дата оформления</th>
            <th>Товары</th>
            <th>Комментарий</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->user()->name); ?></td>
                <td><?php echo e($value->order_id); ?></td>
                <td><?php echo e(date('d.m.Y H:i', $value->date)); ?></td>
                <td><?php echo $value->goods; ?></td>
                <td><?php echo e($value->comment); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>