<?php $__env->startSection('title', 'Список заказов'); ?>
<?php $__env->startSection('header', 'Список заказов'); ?>

<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('goods.list', ['category_id' => 'all'])); ?>" class="btn btn-link">Вернуться к оформлению заказа</a>
    <table class="table" border="0">
        <thead>
        <tr>
            <th>№ заказа</th>
            <th>Дата оформления</th>
            <th>Комментарий</th>
            <th>Действия</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($value->order_id); ?></td>
                <td><?php echo e(date('d.m.Y H:i', $value->date)); ?></td>
                
                <td><?php echo e($value->comment); ?></td>
                <td>
                    <a href="<?php echo e(route('order.watch', $value->id)); ?>" target="_blank">Открыть</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>