<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{

    public $timestamps = false;

//    public function goods()
//    {
//
//        return $this->belongsTo(Good::class, 'good_id','id')->get();
//
//    }

}
